package LinkedList;
/**
 * 
 * @author Michael Smith
 *
 */
public class IntNode {

   int value;
   IntNode next;
/**
 * Default constructor for the IntNode object.
 * This is the building block for the linked list data structure.
 */
   public IntNode(){
   
      value = 0;
      next = null;
   
   }
/**
 * 
 * @param _data This is the parameter to create a single node linked list with this as the node's value.
 * @param _node This will be the link to the next node.
 */
   public IntNode(int _data, IntNode _node) {
   
      value = _data;
      next = _node;
   
   }
/**
 * 
 * @return Returns the value of the called node.
 */
   public int getNodeValue() {
   
      return value;
   
   }
/**
 * 
 * @return Returns the next node in the list from the called node.
 */
   public IntNode getNodeLink() {
   
      return next;
   
   }
/**
 * 
 * @param x Sets the value of the called node to the parameter.
 */
   public void setNodeValue(int x) {
   
      value = x;
   
   }
/**
 * 
 * @param x Sets the link of the current node to the parameter.
 */
   public void setNodeLink(IntNode x) {
   
      next = x;
   
   }
/**
 * 
 * @param head This is the starting point for the method to return the list length.
 * @return If the node is not null returns 1 + a recursive call to the function until the node is null then returns just 1.
 */
   public static int listLength(IntNode head) {
   
      if(head.next != null) {
         return 1 + listLength(head.next);
         
      } 
      return 1;   
      
   }
/**
 * This toString method uses a helper method to print the Linked List.
 */
   public String toString() {
   
      return toStringHelper();
   
   }
/**
 * 
 * @return returns a String that is the formated Linked list.
 */
   public String toStringHelper() {
   
      if(next != null) return Integer.toString(value).concat("->").concat(next.toStringHelper());
      return Integer.toString(value);
   }
/**
 * 
 * @param newdata This parameter is the value of the node that will be after the called node.
 */
   public void addNodeAfterThis(int newdata) {
      
      IntNode nodeNew = new IntNode(newdata, next);
      next = nodeNew;
   
   }
/**
 * 
 * @param head This is the node of which its value will be tested to be tested against the data parameter.
 * @param data This is the value that the called method is looking for.
 * @return if the value at head is the same as data returns true, if not is recursive calls the function again with the next node as the head unless the value is null then it returns false.
 */
   public static boolean search(IntNode head, int data) {
   
      if(head.value == data) return true;
      
      if(head.next == null) return false;
      
      return search(head.next, data);
   
   }
/**
 * Removes the node after the called node in the linked list.
 */
   public void removeNodeAfterThis() {
   
      next = next.next;
   
   }
/**
 *  
 * @param head This is the Node at which the process the find the amount of even numbers begins
 * @return returns the amount of even numbers in the linked list from the point of the head onward
 */
   public static int listEvenNumber(IntNode head) {
	   
	   if(head == null) return 0;
	   
	   if(head.value % 2 == 0) {
	         
		   return 1 + listEvenNumber(head.next);
		   
	   }
	   
	   else return listEvenNumber(head.next);   
	   
   }
/**
 *   
 * @param newdata The value at which to change the last node's value to.
 */
   public void addToEnd(int newdata) {
	   
	   findEnd(this).setNodeValue(newdata);
	   
   }
/**
 * Helper function the find the last Node
 * @param head the point at which to start looking
 * @return returns the node that has the null pointer
 */
   public static IntNode findEnd(IntNode head) {
	   
	   if(head.next == null) return head;
	   
	   return findEnd(head.next);
	   
	   
   }
/**
 * 
 * @param head The point at which the start the linked list that the function will reference
 * @param num the last num elements in which to sum
 * @return the sum of the last num elements
 */
   public static int sumLast(IntNode head, int num) {
	   
	   if(num <= 0) return 0;
	   
	   int buffer = listLength(head) - num;
	   
	   
	   if(head.next == null) { 
		   return head.value;
		   
	   }
		   
	   if(num >= listLength(head) && buffer <= 0) {
		   return head.value + sumLast(head.next, num);
	   }
	   
	   return sumLast(head.next, num);
	   
   }
/**
 * 
 * @param head The point at which to start the linked list that the function will refer to
 * @return returns the head of a new Linked List that contains all the odds from the passed linked list
 */
   public static IntNode copyOdd(IntNode head) {
	   
	   if(head == null) return null;
	   
	   IntNode oddList;
	   
	   if(head.value % 2 != 0) {
		   oddList = new IntNode(head.value, null);
		   return oddLinker(oddList, head);
	   }
	  
	   return copyOdd(head.next);
   }
/**
 * helper for the copyOdd function 
 * @param oddList the head at which the link the rest of the odd nodes
 * @param checker the linked list at which to compare to
 * @return returns the head with all nodes linked
 */
   public static IntNode oddLinker(IntNode oddList, IntNode checker) {
	   
	   if(checker.next == null) return null;
	   
	   if(checker.next.value % 2 != 0) {
		   System.out.println("ODD!");
		   oddList.addNodeAfterThis(checker.next.value);
		   oddLinker(oddList.next, checker.next);
		    
	   }
			   
	   return oddLinker(oddList, checker.next);
			 
	   
	   
   }
   
   
/**
 * 
 * @param head The point at which to start looking for the values to remove
 * @param e the value that will be removed from the linked list
 * @return returns the head of the linked list with the value e now removed
 */
   public static IntNode removeAll(IntNode head, int e) {

	   if(head.next == null) return null;
	   
	   if(head.next.value == e) {
		   System.out.println(head.value);
		   head.removeNodeAfterThis();
		   return removeAll(head, e);
	   }
	   

	   return removeAll(head.next, e);

   }
/**
 * helper function to find the node at a given spot in the index
 * @param head the starting point
 * @param x the "index" of the node
 * @return the node at the index x
 */
   public static IntNode findIntNodeAtIndex(IntNode head, int x) {
	   
	   if(x < 0) return null;
	   
	   if(head == null) return null;
	   
	   if (x != 0) return findIntNodeAtIndex(head.next, x - 1);
	   
	   return head;
	   
   }
/**
 * 
 * @param head The point at which the function will reverse the linked list
 * @return returns the linked list now in reverse order
 */
   public static IntNode reverse(IntNode head) {
	   
	   int[] workingArray = new int[listLength(head)];
	   
	   workingArray = LinkedListToArray(head);
	   
	   IntNode newHead = new IntNode(workingArray[listLength(head) - 1], null);
	   
	   return backwardsLinker(newHead, workingArray, workingArray.length - 2);
	   

	   
   }
/**
 * 
 * @param head the point at which to start looking for a cycle in the linked list
 * @return true if an error occurs because a loop will cause a stack overflow error on the listlength method and false is the listlength method does not throw an exception
 */
   public static boolean hasCycle(IntNode head) {
	  
	   
	  try {
		  listLength(head);
	  }
	  catch(StackOverflowError e) {
		  return true;  
	  }
	  
	  return false;
	  	
	   
   }
/**
 * helper to convert a linked list to an array
 * @param head the starting point in the linked list for the array
 * @return returns the linked list converted to an array
 */
   public static int[] LinkedListToArray(IntNode head) {
	   
	   int[] array = new int[listLength(head)];
	   
	   for(int i = 0; i < listLength(head); i++)
		   array[i] = findIntNodeAtIndex(head, i).value;
	   
	   return array;
	   
   }
/**
 * helper for the reverse method
 * @param head the point at which to start
 * @param array a the array the linker copies values from
 * @param position the value that gets passed recursively to keep track of values already put into nodes
 * @return returns the head of the now reversed linked list
 */
   public static IntNode backwardsLinker(IntNode head, int[] array, int position) {
	   
	   if(position >= 0) {
		   
		   head.addNodeAfterThis(array[position]);
		   backwardsLinker(head.next, array, position - 1);  
		   
	   }
	   
	   return head;
	  
   }
   
   
   
}