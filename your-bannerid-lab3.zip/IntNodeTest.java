package LinkedList;

public class IntNodeTest {
	
	public static void main(String[] args) {
		   
		IntNode node1 = new IntNode(98, null);
		IntNode node2 = new IntNode(22, node1);
		IntNode node3 = new IntNode(87, node2);
		IntNode node4 = new IntNode(90, node3);
		IntNode node5 = new IntNode(56, node4);
		  
		System.out.println();
		System.out.println("Length is: " + IntNode.listLength(node5));
		System.out.println();
		System.out.println("node5 contains 5? " + IntNode.search(node5, 5));
		System.out.println();
		System.out.println("node5 contains 56? " + IntNode.search(node5, 56));
		System.out.println();
		  
		node3.addNodeAfterThis(999);
		System.out.println("The String from node5 is: " + node5.toString());
		System.out.println();
		System.out.println("Length is: " + IntNode.listLength(node5));
		
		node3.removeNodeAfterThis();
		
		System.out.println();
		System.out.println("Length is: " + IntNode.listLength(node5));
		System.out.println();  
		System.out.println("The String from node3 is: " + node3.toString());
		System.out.println();
		System.out.println("The String from node5 is: " + node5.toString());
		
		}
	   
}
