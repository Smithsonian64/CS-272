package LinkedList;
/**
 * 
 * @author Michael Smith
 *
 */
public class IntNode {

   int value;
   IntNode next;
/**
 * Default constructor for the IntNode object.
 * This is the building block for the linked list data structure.
 */
   public IntNode(){
   
      value = 0;
      next = null;
   
   }
/**
 * 
 * @param _data This is the parameter to create a single node linked list with this as the node's value.
 * @param _node This will be the link to the next node.
 */
   public IntNode(int _data, IntNode _node) {
   
      value = _data;
      next = _node;
   
   }
/**
 * 
 * @return Returns the value of the called node.
 */
   public int getNodeValue() {
   
      return value;
   
   }
/**
 * 
 * @return Returns the next node in the list from the called node.
 */
   public IntNode getNodeLink() {
   
      return next;
   
   }
/**
 * 
 * @param x Sets the value of the called node to the parameter.
 */
   public void setNodeValue(int x) {
   
      value = x;
   
   }
/**
 * 
 * @param x Sets the link of the current node to the parameter.
 */
   public void setNodeLink(IntNode x) {
   
      next = x;
   
   }
/**
 * 
 * @param head This is the starting point for the method to return the list length.
 * @return If the node is not null returns 1 + a recursive call to the function until the node is null then returns just 1.
 */
   public static int listLength(IntNode head) {
   
      if(head.next != null) {
         return 1 + listLength(head.next);
         
      } 
      return 1;   
      
   }
/**
 * This toString method uses a helper method to print the Linked List.
 */
   public String toString() {
   
      return toStringHelper();
   
   }
/**
 * 
 * @return returns a String that is the formated Linked list.
 */
   public String toStringHelper() {
   
      if(next != null) return Integer.toString(value).concat("->").concat(next.toStringHelper());
      return Integer.toString(value);
   }
/**
 * 
 * @param newdata This parameter is the value of the node that will be after the called node.
 */
   public void addNodeAfterThis(int newdata) {
      
      IntNode nodeNew = new IntNode(newdata, next);
      next = nodeNew;
   
   }
/**
 * 
 * @param head This is the node of which its value will be tested to be tested against the data parameter.
 * @param data This is the value that the called method is looking for.
 * @return if the value at head is the same as data returns true, if not is recursive calls the function again with the next node as the head unless the value is null then it returns false.
 */
   public static boolean search(IntNode head, int data) {
   
      if(head.value == data) return true;
      
      if(head.next == null) return false;
      
      return search(head.next, data);
   
   }
/**
 * Removes the node after the called node in the linked list.
 */
   public void removeNodeAfterThis() {
   
      next = next.next;
   
   }
     
}