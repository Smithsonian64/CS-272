/*************************************************************************
*****
*  A Stringset is a collection of Strings.
*  The same Sring may not appear multiple times in a bag.
*
*  @note
*  (1) The capacity of one of these bags can change after it's created,  but
*  the maximum capacity is limited by the amount of free memory on the
*  machine.
*  <p>
*
*  @author Michael Smith
*  <A HREF="mailto:p173939@nmsu.edu"> (p173939@nmsu.edu) </A>
*  Huiping Cao modified
*
*  @version
*  Feb 7, 2019
**************************************************************************
****/
class StringSet {

   int numOfElements;
   String[] elements;
   
   public StringSet() {
   
   numOfElements = 2;
   elements = new String[2];
   
   }
   
   /**
*  Initialize an empty bag with a specified initial capacity. 
*  @param _capacity
*  the initial capacity
*  @precondition
*  Capacity is non-negative.
*  @postcondition
*  This bag is empty and has the given initial capacity.
*  @exception IllegalArgumentException
*  Indicates that initialCapacity is negative.
**/
   
   public StringSet(int _capacity) {
   
      //numOfElements = _capacity;
      elements = new String[_capacity];
   
   }
   
     /**
*  Initialize a bag with contents of the parameter. 
*  @param obj
*  the initializing StringSet object
*  @precondition
*  obj is not null
*  @postcondition
*  This bag has the same content as the parameter
**/
  
   public StringSet(StringSet obj){
   
      numOfElements = obj.numOfElements;
      elements = new String[obj.elements.length];
   
   }
   
/**
*  Return size of the bag
*  @param none

*  @precondition
*  size is non-negative.
*  @postcondition
*  none
**/
   
   public int size() {
   
      return (numOfElements);
   
   }
   
/**
*  Return the capacity of the bag
*  @param none
*  @precondition
*  Capacity is non-negative.
*  @postcondition
*  none
**/
   
   public int capacity() {
   
      return (elements.length);
   
   }
   

   /**
*  adds a String to the bag
*  @param a
*  the String to be added
*  @precondition
*  a is a String
*  @postcondition
*  This bag has the additional String in it and is bigger if there was not enough room 
**/

   public void add(String a) {
   
      
      
      for(int i = 0; i < elements.length; i++) {
      
         if(elements[i] == null) { 
            elements[i] = a;
            numOfElements++;
            return;
            
         }
      }   
         
         ensureCapacity(elements.length + 1);
         add(a);
         
   }
   
  
/**
*  removes the string within the bag
*  @param a
*  the string in the bag to be removed
*  @precondition
*  a is a string within the bag
*  @postcondition
*  This bag is empty and has the given initial capacity.
**/
  
   public boolean remove(String a) {
   
      for(int i = 0; i < elements.length; i++) {
      
         if(a == null)
            return (false);
         
         if(elements[i] == a) {
         
            elements[i] = null;
            for(int j = i; j < elements.length - 1; j++) 
               elements[j] = elements[j + 1];
            elements[elements.length - 1] = null;      
            numOfElements--;
            return (true);
         
         }
      
      }
      
      return (false);
   
   }
   
/**
*  When called, doubles the size of the bag
*  @param minimumCapacity
*  the size that the bag must at least be to contain the next item
*  @precondition
*  minimumCapacity is bigger than the current size of the bag
*  @postcondition
*  The bag is doubles its original size
**/
   
   private void ensureCapacity(int minimumCapacity) {
   
      if(elements.length < minimumCapacity) {
      
         //numOfElements = minimumCapacity;
         String[] elementsTemp = new String[elements.length * 2];
         for(int i = 0; i < elements.length; i++)
            elementsTemp[i] = elements[i];
         elements = new String[elements.length * 2];
         for(int i = 0; i < elements.length; i++)
            elements[i] = elementsTemp[i];  
    
      }
   
   }
   
   /**
*  adds a String in alphabetical order in the bag
*  @param a
*  the string to be added
*  @precondition
*  a is a String and not already in the bag
*  @postcondition
*  The bag now has the string and is in alphabetical order
**/
   
   public void addOrdered(String a) {
   
      if(elements.length == numOfElements)
         ensureCapacity(elements.length + 1);
         
      
   
       for(int k = 0; k <= a.length(); k++) { 
               //System.out.println("k:" + k);
       
         for(int i = 0; i < elements.length; i++) {
            System.out.println("i:" + i);           
               if(a.charAt(0) < elements[i].charAt(0)) { 
                  for(int j = elements.length - 1; j > i; j--) {
                     elements[j] = elements[j - 1];
                  }
                  elements[i] = a;
                  numOfElements++;
                  return;
               }
            }
            
            
            
       }    
            
         
         
         
         
   
   }
   
   
   
   public static void main(String[] args) {
   
      StringSet set1 = new StringSet();
      System.out.println(set1.size());
      System.out.println(set1.capacity());
      
      System.out.println();
      
      StringSet set2 = new StringSet(5);
      System.out.println(set2.size());
      System.out.println(set2.capacity());
      
      for(int i = 0; i < set2.elements.length; i++)
         System.out.print(set2.elements[i] + " ");
      
      System.out.println();
      
      StringSet set3 = new StringSet(63);
      StringSet set4 = new StringSet(set3);
      System.out.println(set4.size());
      System.out.println(set4.capacity());
      
      System.out.println();
      
      set2.add("Hello");
      System.out.println(set2.elements[0]);
      
      System.out.println();
      
      set2.add("World");
      System.out.println(set2.size());
      System.out.println(set2.capacity());
      System.out.println(set2.elements[0]);
      System.out.println(set2.elements[1]);
      set2.add("Mercury");
      System.out.println(set2.size());
      set2.add("Mars");
      set2.add("Venus");
      System.out.println(set2.size());
      for(int i = 0; i < set2.elements.length; i++)
         System.out.print(set2.elements[i] + " ");
      set2.add("Jupiter");
      System.out.println();
      //System.out.println(set2.size());
      //System.out.println(set2.capacity());
      for(int i = 0; i < set2.elements.length; i++)
         System.out.print(set2.elements[i] + " ");
      System.out.println();
      System.out.println(set2.size());
      System.out.println(set2.capacity());
         
      System.out.println();
      
      set2.remove("Mars");
      for(int i = 0; i < set2.elements.length; i++)
         System.out.print(set2.elements[i] + " ");
      System.out.println();
      System.out.println(set2.size());
      System.out.println(set2.capacity());
      
      System.out.println();
      
      StringSet set5 = new StringSet(5);
      set5.add("Alpha");
      set5.add("Bravo");
      set5.add("Charlie");
      set5.add("Echo");
      set5.add("Foxtrot");
      for(int i = 0; i < set5.elements.length; i++)
         System.out.print(set5.elements[i] + " ");
       
      System.out.println();
      System.out.println();
         
      set5.addOrdered("Ciarlie");
      set5.addOrdered("Cjarlie");
      
      
      System.out.println();
      
      for(int i = 0; i < set5.elements.length; i++)
         System.out.print(set5.elements[i] + " ");
   
   }
   
}

