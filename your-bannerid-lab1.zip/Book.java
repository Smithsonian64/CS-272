public class Book {                                   //
                                                      //
    String bookTitle;                                 // The Book object has four variables
    int numOfAuthors;                                 //
    String[] authors;                                 //
    String ISBN;                                      //
    
    public Book() {                                   //
                                                      //
        bookTitle = null;                             //
        ISBN = null;                                  // 
        numOfAuthors = 0;                             //
        authors = new String[3];                      //
                                                      //
    }                                                 //
                                                      // The Book object can be called with no arguments to create a Book
                                                      // with default values or called with a String argument to create 
    public Book (String _title) {                     // a Book object with default values but the bookTitle variable as
                                                      // the String argument
        bookTitle = _title;                           //
        ISBN = null;                                  //
        numOfAuthors = 0;                             //
        authors = new String[3];                      //
                                                      //
    }                                                 //
                                                                                                            
    public Book (Book obj) {                          //
                                                      //            
        bookTitle = obj.bookTitle;                    // 
        ISBN = obj.ISBN;                              // This method should use a book object as an argument and
        numOfAuthors = obj.numOfAuthors;              // the instance should not be null
        authors = obj.authors;                        //
                                                      //
    }                                                 //
    
    public String getTitle () {                       //
                                                      // Returns the bookTitle variable of the Book object
        return (bookTitle);                           //                                             
    }                                                 //
    
    public int getAuthorNumber() {                    //
                                                      //
      return (numOfAuthors);                          // Returns the number of authors from the Book object
                                                      //
    }                                                 //
    
    public String getISBN() {                         //
                                                      //
        return (ISBN);                                // Returns the ISBN from the Book object
                                                      //
    }                                                 //
    
    public void setTitle (String _title) {            //
                                                      //
        bookTitle = _title;                           // Sets the bookTitle variable of the Book object to the argument
                                                      //
    }                                                 //
    
    public void setISBN (String _ISBN) {              //
                                                      //
      ISBN = _ISBN;                                   // Sets the ISBN of the Book object to the argument
                                                      //
    }                                                 //
    
    public boolean addAuthor (String _author) {       //
                                                      //
      for(int i = 0; i < 3; i++) {                    //
                                                      //
         if (authors[i] == null) {                    //
                                                      //
            authors[i] = _author;                     // If the authors array has values in all three of its indexes the
            numOfAuthors++;                           // method will return false. If there is at least one open index it will
            return (true);                            // fill the index with the argument starting from the leastmost index
                                                      //
         }                                            //
                                                      //
      }                                               //
                                                      //
    return (false);                                   //
                                                      //
    }                                                 //
    
    public boolean equals (Book obj) {                //
                                                      //
      if (ISBN == obj.ISBN) return (true);            //
                                                      // Checks if the ISBN of the called Book object and the argument Book
      else return (false);                            // Object are the same value. Returns true if they are and false if they
                                                      // are not. the argument should be a book object and not null
    }                                                 //
    
    public static String[] getAllAuthors (Book b1, Book b2) {//
                                                      //
      String[] output = new String[6];                //
                                                      //
      for(int i = 0; i < 3; i++) {                    // 
                                                      // 
      output[i] = b1.authors[i];                      //
      output[i + 3] = b2.authors[i];                  // returns a 6 element array that puts the authors from the first Book
                                                      // argument in the first three elements and puts the authors from the
      }                                               // second Book argument in the last three elements. The arguments should 
                                                      // not be null
    return (output);                                  //
                                                      //
    }                                                 //
    
    public String toString() {                        //
                                                      // 
      return (String.format("%s, %s, %d, %s, %s, %s", bookTitle, ISBN, numOfAuthors, authors[0], authors[1], authors[2]));//
                                                      // toString method that returns the called Book object's instance variables
    }                                                 // in a formated String
    
    
                                                      
    public static void main(String[] args){           //main method
                                                            
      Book novel = new Book();                        //
                                                      //
      System.out.println(novel.bookTitle);            //
      System.out.println(novel.ISBN);                 // Tests the default constructor and ensures the
      System.out.println(novel.numOfAuthors);         // default variables are correct
      for(int i = 0; i < 3; i++)                      //
         System.out.print(novel.authors[i] + " ");    //
         
      System.out.println();
      System.out.println();
      
      Book novel2 = new Book("Hello World");          //
                                                      //
      System.out.println(novel2.bookTitle);           //
      System.out.println(novel2.ISBN);                // Tests the constructor that sets a title and ensures that
      System.out.println(novel2.numOfAuthors);        // the variables are correct as well
      for(int i = 0; i < 3; i++)                      //
         System.out.print(novel2.authors[i] + " ");   //
         
      System.out.println();
      System.out.println();
      
      Book novel3 = new Book("copyTester");           //
                                                      //
      novel3.setTitle("COPYTESTER");                  //
      novel3.setISBN("123456789");                    //
      novel3.addAuthor("Me");                         //
                                                      // Tests setTite(), setISBN, and addAuthor
      System.out.println(novel3.bookTitle);           //
      System.out.println(novel3.ISBN);                //
      System.out.println(novel3.numOfAuthors);        //
      for(int i = 0; i < 3; i++)                      // 
         System.out.print(novel3.authors[i] + " ");   //
         
      System.out.println();
      System.out.println();
      
      Book novel4 = new Book(novel3);                 //
                                                      //
      System.out.println(novel4.bookTitle);           //
      System.out.println(novel4.ISBN);                // Tests the copy constructor and ensures the variables are correct
      System.out.println(novel4.numOfAuthors);        //
      for(int i = 0; i < 3; i++)                      //
         System.out.print(novel4.authors[i] + " ");   //
         
      System.out.println();
      System.out.println();
      
      System.out.println(novel.equals(novel4));       // Tests the equals() method with both possibilites
      System.out.println(novel3.equals(novel4));      //
      
      System.out.println();
      
      System.out.println(novel4.toString());          // Tests the toString method
      
      System.out.println();
      
      Book novel5 = new Book("Here");                 //     
      novel5.addAuthor("Red");                        //   
      novel5.addAuthor("Green");                      //
      novel5.addAuthor("Blue");                       //
      novel5.setISBN("987654321");                    //
                                                      //
      Book novel6 = new Book("There");                // Tests the get methods
      novel6.addAuthor("One");                        //
      novel6.addAuthor("Two");                        //
      novel6.addAuthor("Three");                      //
                                                      //
      System.out.println(novel5.getTitle());          //
      System.out.println(novel5.getISBN());           //
      System.out.println(novel5.getAuthorNumber());   //
      
      System.out.println();
      
      String[] tester = getAllAuthors(novel5, novel6);//
      for(int i = 0; i < 6; i++)                      // Tests the getAllAuthors() method
         System.out.print(tester[i] + " ");           //
                                                      //
    }                                                 //
                                                      //
}